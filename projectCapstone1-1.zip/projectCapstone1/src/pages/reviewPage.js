import React from 'react';
import ContactApp from '../components/ContactApp';

function ReviewPage() {
	return (
		<>
			<ContactApp />
		</>
	);
}

export default ReviewPage;
