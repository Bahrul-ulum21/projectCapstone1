import React from 'react';
import FaqApp from '../componentsfaq/FaqApp';

function FaqPage() {
	return (
		<>
			<FaqApp />
		</>
	);
}

export default FaqPage;
