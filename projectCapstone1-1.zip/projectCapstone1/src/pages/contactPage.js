import React from 'react';
import RukoApp from '../componentsDetailRuko/RukoApp';

function ContactPage() {
	return (
		<>
			<RukoApp />
		</>
	);
}

export default ContactPage;
